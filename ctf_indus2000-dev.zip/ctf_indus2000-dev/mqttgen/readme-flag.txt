Les scripts de ce dossier servent à simuler le jeu de données des machines industrielles.
OK, c'est la bonne cuve.
