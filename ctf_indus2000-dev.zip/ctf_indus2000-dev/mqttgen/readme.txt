Les scripts de ce dossier servent à simuler le jeu de données des machines industrielles.
Test une autre cuve !
