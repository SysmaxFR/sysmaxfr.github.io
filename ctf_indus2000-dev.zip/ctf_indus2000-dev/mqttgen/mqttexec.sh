#!/bin/sh

host='proxy'
username='indus-admin'
password='systemofadown'
topic="controls/$HOSTNAME"
file="/tmp/mosquitto_exec"

while true
do
  EXEC=$(mosquitto_sub -h $host -u $username -P $password -t $topic -C 1)
  $EXEC > $file

  RETURN='{"id": "'$HOSTNAME'-script", "value": "'$(cat $file)'", "unit": "sh", "type": "script", "description": "commande sondes"}'
  echo $RETURN > $file

  mosquitto_pub -h $host -u $username -P $password -t $topic -f $file
done
