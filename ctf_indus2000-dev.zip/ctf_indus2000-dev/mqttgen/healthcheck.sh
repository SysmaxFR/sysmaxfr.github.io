#!/bin/sh

CHECK_1=$(ps aux | grep '[m]qttexec')
EXIT_1=$?
CHECK_2=$(ps aux | grep '[m]osquitto')
EXIT_2=$?

if [ $EXIT_1 != 0 ] || [ $EXIT_2 != 0 ]
then
   exit 1
fi
