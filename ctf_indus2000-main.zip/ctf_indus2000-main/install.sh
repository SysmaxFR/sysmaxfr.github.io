#! /bin/bash

confirm()
{
  read -r -p "${1} [y/N] " response
  case "$response" in
    [yY][eE][sS] | [yY])
      true
      ;;
    *)
      false
      ;;
  esac
}

install()
{
  export DEBIAN_FRONTEND=noninteractive

  # Mise à jour du systeme
  apt update && apt upgrade -y

  # Installation de docker-ce et de docker-compose
  apt-get remove docker docker-engine docker.io containerd runc -y
  apt-get install ca-certificates curl gnupg lsb-release git cron nano iputils-ping -y
  mkdir -p /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
  apt-get update
  apt-get install docker-ce docker-ce-cli containerd.io docker-compose-plugin -y

  # Ajout du lancement automatique + gestion du healthcheck
  crontab -l > crontab.edit
  echo "@reboot    docker compose -f $(pwd)/docker-compose.yml up" >> crontab.edit
  echo '* * * * *  sleep 30; HEALTHCHECK=$(docker ps --all --quiet --filter "health=unhealthy"); docker restart $HEALTHCHECK' >> crontab.edit
  crontab crontab.edit
  rm crontab.edit

  # Ajout de l'ip dhcp visible au démarrage
  echo 'ip: \4{ens32} \4{enp0s3}' | tee -a /etc/issue

  # Désactivation du service ssh
  systemctl disable sshd

  # Lancement de l'epreuve
  echo " "
  echo "--> ATTENTION <--"
  echo "--> reboot auto dans 15 seconde <--"
  sleep 15
  reboot
}

echo " "
echo "--> Attention la vm va redemarrer automatiquement à la fin du script"
echo "--> Après le redémarrage de la vm, l'infra docker sera up après 2 minutes"
if confirm 'La VM est-elle une "fresh install", lancer le script ?'; then
  install
else
  echo "Arrêt, si la vm n'est pas une "fresh install", réaliser le script manuellement"
fi
