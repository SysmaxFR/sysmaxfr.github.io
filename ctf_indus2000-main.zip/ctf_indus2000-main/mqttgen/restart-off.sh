echo "redemarrage $HOSTNAME [en cours]"
echo "redemarrage $HOSTNAME [stop]"
