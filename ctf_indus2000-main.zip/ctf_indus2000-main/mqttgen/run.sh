#/bin/sh

sleep 10
sh /mqttgen/mqttexec.sh &
python3 /mqttgen/mqttgen.py /mqttgen/config-c*.json
